(globalThis["TURBOPACK_CHUNK_LISTS"] || (globalThis["TURBOPACK_CHUNK_LISTS"] = [])).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: ["static/chunks/_0bdus8d._.js","static/chunks/node_modules_0v_rs91._.js"],
    source: "dynamic"
});

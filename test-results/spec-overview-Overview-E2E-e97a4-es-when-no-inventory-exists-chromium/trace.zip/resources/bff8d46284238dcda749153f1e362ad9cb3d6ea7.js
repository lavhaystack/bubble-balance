(globalThis["TURBOPACK_CHUNK_LISTS"] || (globalThis["TURBOPACK_CHUNK_LISTS"] = [])).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: ["static/chunks/_0s-7kpn._.js","static/chunks/node_modules_0z4q~11._.js"],
    source: "dynamic"
});

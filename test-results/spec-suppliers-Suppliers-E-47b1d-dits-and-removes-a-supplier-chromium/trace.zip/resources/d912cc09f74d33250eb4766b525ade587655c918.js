(globalThis["TURBOPACK_CHUNK_LISTS"] || (globalThis["TURBOPACK_CHUNK_LISTS"] = [])).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: ["static/chunks/_01wsrx_._.js","static/chunks/node_modules_00w60gn._.js"],
    source: "dynamic"
});

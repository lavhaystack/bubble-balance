(globalThis["TURBOPACK_CHUNK_LISTS"] || (globalThis["TURBOPACK_CHUNK_LISTS"] = [])).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: ["static/chunks/_0qykxt.._.js","static/chunks/node_modules_0im34cd._.js"],
    source: "dynamic"
});
